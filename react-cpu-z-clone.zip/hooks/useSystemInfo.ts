
import { useState, useEffect } from 'react';
import { getSystemInfo } from '../services/systemInfoService';
import { SystemInfo } from '../types';

export const useSystemInfo = () => {
  const [systemInfo, setSystemInfo] = useState<SystemInfo | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchInfo = async () => {
      setLoading(true);
      const info = await getSystemInfo();
      setSystemInfo(info);
      setLoading(false);
    };

    fetchInfo();
  }, []);

  return { systemInfo, loading };
};
