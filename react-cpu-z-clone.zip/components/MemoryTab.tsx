
import React from 'react';
import { MemoryInfo } from '../types';
import InfoCard from './InfoCard';
import InfoField from './InfoField';

interface MemoryTabProps {
  data: MemoryInfo;
}

const MemoryTab: React.FC<MemoryTabProps> = ({ data }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <InfoCard title="General">
        <InfoField label="Type" value={data.type} />
        <InfoField label="Size" value={data.size} />
        <InfoField label="Channels #" value={data.channels} />
      </InfoCard>

      <InfoCard title="Timings">
        <InfoField label="DRAM Frequency" value={data.dramFrequency} />
        <InfoField label="CAS# Latency (CL)" value={data.casLatency} />
        <InfoField label="RAS# to CAS# Delay" value={data.rasToCasDelay} />
        <InfoField label="RAS# Precharge (tRP)" value={data.rasPrecharge} />
        <InfoField label="Cycle Time (tRAS)" value={data.cycleTime} />
      </InfoCard>
    </div>
  );
};

export default MemoryTab;
