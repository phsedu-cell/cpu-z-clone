
import React from 'react';
import { MainboardInfo } from '../types';
import InfoCard from './InfoCard';
import InfoField from './InfoField';

interface MainboardTabProps {
  data: MainboardInfo;
}

const MainboardTab: React.FC<MainboardTabProps> = ({ data }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <InfoCard title="Motherboard">
        <InfoField label="Manufacturer" value={data.manufacturer} />
        <InfoField label="Model" value={data.model} />
        <InfoField label="Chipset" value={data.chipset} />
        <InfoField label="Southbridge" value={data.southbridge} />
      </InfoCard>

      <InfoCard title="BIOS">
        <InfoField label="Brand" value={data.bios.brand} />
        <InfoField label="Version" value={data.bios.version} />
        <InfoField label="Date" value={data.bios.date} />
      </InfoCard>
    </div>
  );
};

export default MainboardTab;
