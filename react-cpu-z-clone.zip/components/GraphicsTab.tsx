
import React from 'react';
import { GraphicsInfo } from '../types';
import InfoCard from './InfoCard';
import InfoField from './InfoField';

interface GraphicsTabProps {
  data: GraphicsInfo;
}

const GraphicsTab: React.FC<GraphicsTabProps> = ({ data }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <InfoCard title="GPU">
        <InfoField label="Name" value={data.gpu.name} />
        <InfoField label="Manufacturer" value={data.gpu.manufacturer} />
        <InfoField label="Technology" value={data.gpu.technology} />
      </InfoCard>
      
      <InfoCard title="Clocks">
        <InfoField label="Core" value={data.clocks.core} />
        <InfoField label="Memory" value={data.clocks.memory} />
      </InfoCard>

      <div className="md:col-span-2">
        <InfoCard title="Memory">
            <InfoField label="Size" value={data.memory.size} />
            <InfoField label="Type" value={data.memory.type} />
            <InfoField label="Bus Width" value={data.memory.busWidth} />
        </InfoCard>
      </div>
    </div>
  );
};

export default GraphicsTab;
