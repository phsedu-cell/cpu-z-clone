import React from 'react';
import InfoCard from './InfoCard';

const AboutTab: React.FC = () => {
  return (
    <div className="space-y-6">
      <InfoCard title="About React CPU-Z">
        <p className="text-sm text-slate-300 leading-relaxed">
          This application is a clone of the popular hardware specification utility CPU-Z, built for the web using modern frontend technologies. It serves as a demonstration of building a data-driven UI with a clean, responsive, and aesthetically pleasing design.
        </p>
      </InfoCard>
      
      <InfoCard title="Technologies Used">
        <ul className="list-disc list-inside space-y-2 text-sm text-slate-300">
          <li><strong>React 18:</strong> For building the user interface with functional components and hooks.</li>
          <li><strong>TypeScript:</strong> For robust type safety and improved developer experience.</li>
          <li><strong>Tailwind CSS:</strong> For a utility-first approach to styling, enabling rapid development of a custom, responsive design inspired by Material Design.</li>
          <li><strong>Vite:</strong> As the frontend tooling for a fast development experience. (Assumed environment)</li>
        </ul>
      </InfoCard>
      
      <InfoCard title="Important Note">
        <p className="text-sm text-slate-300 leading-relaxed">
          Due to web browser security limitations, this application cannot access real hardware information from your system. All data displayed is simulated for demonstration purposes to accurately mimic the look and feel of the original CPU-Z software.
        </p>
      </InfoCard>

      <div className="text-center pt-8">
        <p className="text-sm text-slate-400">Designed and Developed by: Subrato Das</p>
      </div>
    </div>
  );
};

export default AboutTab;
