
import React from 'react';

interface InfoFieldProps {
  label: string;
  value: string | number;
}

const InfoField: React.FC<InfoFieldProps> = ({ label, value }) => {
  return (
    <div className="flex items-center text-sm">
      <span className="w-2/5 text-slate-400">{label}</span>
      <span className="w-3/5 font-medium text-slate-200">{value}</span>
    </div>
  );
};

export default InfoField;
