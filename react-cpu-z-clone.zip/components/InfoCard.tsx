
import React from 'react';

interface InfoCardProps {
  title: string;
  children: React.ReactNode;
}

const InfoCard: React.FC<InfoCardProps> = ({ title, children }) => {
  return (
    <div className="bg-slate-800/50 rounded-lg p-4 ring-1 ring-slate-700">
      <h3 className="text-lg font-semibold text-indigo-400 mb-4 pb-2 border-b border-slate-700">{title}</h3>
      <div className="space-y-3">
        {children}
      </div>
    </div>
  );
};

export default InfoCard;
