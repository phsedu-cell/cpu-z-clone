
import React from 'react';
import { CpuInfo } from '../types';
import InfoCard from './InfoCard';
import InfoField from './InfoField';

interface CpuTabProps {
  data: CpuInfo;
}

const CpuTab: React.FC<CpuTabProps> = ({ data }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <InfoCard title="Processor">
        <InfoField label="Name" value={data.name} />
        <InfoField label="Code Name" value={data.codeName} />
        <InfoField label="Max TDP" value={data.maxTdp} />
        <InfoField label="Technology" value={data.technology} />
        <InfoField label="Core Voltage" value={data.coreVoltage} />
      </InfoCard>

      <InfoCard title="Specification">
        <InfoField label="Specification" value={data.specification} />
        <InfoField label="Family" value={data.family} />
        <InfoField label="Model" value={data.model} />
        <InfoField label="Stepping" value={data.stepping} />
        <InfoField label="Revision" value={data.revision} />
        <InfoField label="Instructions" value={data.instructions} />
      </InfoCard>

      <InfoCard title="Clocks (Core #0)">
        <InfoField label="Core Speed" value={data.clocks.coreSpeed} />
        <InfoField label="Multiplier" value={data.clocks.multiplier} />
        <InfoField label="Bus Speed" value={data.clocks.busSpeed} />
      </InfoCard>

      <InfoCard title="Cache">
        <InfoField label="L1 Data" value={data.cache.l1Data} />
        <InfoField label="L1 Inst." value={data.cache.l1Inst} />
        <InfoField label="Level 2" value={data.cache.l2} />
        <InfoField label="Level 3" value={data.cache.l3} />
      </InfoCard>

      <div className="md:col-span-2">
        <InfoCard title="Cores & Threads">
            <InfoField label="Cores" value={data.cores} />
            <InfoField label="Threads" value={data.threads} />
        </InfoCard>
      </div>
    </div>
  );
};

export default CpuTab;
