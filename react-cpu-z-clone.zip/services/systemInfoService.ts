
import { SystemInfo } from '../types';

const mockSystemInfo: SystemInfo = {
  cpu: {
    name: 'Intel Core i9 13900K',
    codeName: 'Raptor Lake',
    maxTdp: '125 W',
    technology: '10 nm',
    coreVoltage: '1.35 V',
    specification: '13th Gen Intel(R) Core(TM) i9-13900K',
    family: '6',
    model: '7',
    stepping: '1',
    revision: 'B0',
    instructions: 'MMX, SSE, SSE2, SSE3, SSSE3, SSE4.1, SSE4.2, EM64T, VT-x, AES, AVX, AVX2, FMA3',
    clocks: {
      coreSpeed: '5800.00 MHz',
      multiplier: 'x 58.0',
      busSpeed: '100.0 MHz',
    },
    cache: {
      l1Data: '8 x 48 KBytes',
      l1Inst: '8 x 32 KBytes',
      l2: '8 x 2048 KBytes',
      l3: '36 MBytes',
    },
    cores: 24,
    threads: 32,
  },
  mainboard: {
    manufacturer: 'ASUSTeK COMPUTER INC.',
    model: 'ROG MAXIMUS Z790 HERO',
    chipset: 'Intel Z790',
    southbridge: 'Intel Z790',
    bios: {
      brand: 'American Megatrends Inc.',
      version: '1303',
      date: '07/11/2023',
    },
  },
  memory: {
    type: 'DDR5',
    size: '32 GBytes',
    channels: 'Dual',
    dramFrequency: '3600.0 MHz',
    casLatency: '36.0 clocks',
    rasToCasDelay: '46 clocks',
    rasPrecharge: '46 clocks',
    cycleTime: '82 clocks',
  },
  graphics: {
    gpu: {
      name: 'NVIDIA GeForce RTX 4090',
      manufacturer: 'NVIDIA',
      technology: '4 nm',
    },
    clocks: {
      core: '2235 MHz',
      memory: '1313 MHz',
    },
    memory: {
      size: '24 GBytes',
      type: 'GDDR6X',
      busWidth: '384-bit',
    },
  },
};

export const getSystemInfo = (): Promise<SystemInfo> => {
  return new Promise((resolve) => {
    // Simulate a network delay
    setTimeout(() => {
      resolve(mockSystemInfo);
    }, 1000);
  });
};
